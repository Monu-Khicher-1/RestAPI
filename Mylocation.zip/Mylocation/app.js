var express = require('express');
var app = express();
var bodyParser=require('body-parser');
var mongoose=require('mongoose');

const User=require('./Models/user');
const Location=require('./Models/location');
const { count } = require('./Models/user');

const DB='mongodb+srv://MyLocationApp:kolinpaulsir@location1.juhxfq7.mongodb.net/DataBase1?retryWrites=true&w=majority'
var password='kolinsir99@';

mongoose.set('strictQuery', true);
mongoose.connect(DB,()=> console.log("Connected to MongoDB."));/*.then(() => {
    console.log('connected to mongoDB...');
}).catch((err) => console.log("Error.. not able to connect with database......"));

*/

app.use(express.json())
app.use(bodyParser.json())

// ----------------ROUTES----------------------
app.get('/',function(req,res){
    res.send("We are at home...");
    console.log("client Requested!");
});

app.post('/api/signin',async function(req,res){
    console.log("client Opened Signin Page!");
    const query=await User.find({name:req.body.name});
    if(query.length>0){
        const user=await User.findOne({name:req.body.name});
        if(user.password==req.body.password){
            res.status(200).send("Sign in successfully.")
        }
        else{
            res.send("Incorrect Password.")
        }
    }
    else{
        res.status(404).send("User doesn't exist.")
    }

});

app.post('/api/signup',async function(req,res){
    // res.send("Signup Page");
    console.log("client Opened Signup Page!");

    const query=await User.find({name:req.body.name});
    console.log(query);
    console.log(query.length);

    if(query.length>0){
        res.send("User already exists");
    }

    else{
        const user=new User({
            name: req.body.name,
            password: req.body.password
        });
        try{
            const savedUser=await user.save();
            res.status(201).json(savedUser);
        }catch(err){
            res.json({message:err});
        }
    }
    
});


app.post('/api/user/upload', async function(req,res){
    console.log("Client is uploading......");
    const user=await User.findOne({name:req.body.name});
    if(user==null){
        res.send("Not Registered. Can't upload.");
    }
    else{
        const location=new Location({
            altitude: req.body.altitude,
            longitude: req.body.longitude
        });
        try{
            const savedLoc=await location.save();
            try{
                user.locationArray.push(savedLoc.id);
                const savedUser=await user.save();
                res.status(201).json({user:savedUser,loc:savedLoc});
            }catch(err){
                res.json({message:err});
            }
            
        }catch(err){
            res.send("Some error.")
        }
    }
})



app.post('/api/users',async(req,res)=>{
    const user=new User({
        name: req.body.name,
        password: req.body.password
    });
    try{
        const savedUser=await user.save();
        res.status(201).json(savedUser);
    }catch(err){
        res.json({message:err});
    }
});


app.get('/api/users',async(req,res)=>{
    try{
        const users =  await User.find();
        console.log(users);
        res.status(200).json(users);
    } catch(err){
        res.json({message:err});
    }

   
    
});

app.listen(3000);
console.log('Running app on port 3000.....');