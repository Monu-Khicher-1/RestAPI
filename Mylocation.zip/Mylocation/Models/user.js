const { json } = require('body-parser');
var mongoose = require('mongoose');

// const Location=require('./location');


var userSchema = mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    locationArray:[{type:mongoose.Schema.Types.ObjectId, ref:'location'}]
      
    // }
    // location:{
    //     type: JSON,
    
})


module.exports = mongoose.model('user',userSchema);

// Get User

// module.exports.getUsers = function(callback,limit){
//     Users.find(callback).limit(limit);
// }