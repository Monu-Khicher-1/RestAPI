const { json } = require('body-parser');
var mongoose = require('mongoose');


var locationSchema = mongoose.Schema({
    altitude:{
        type:String,
        required:true
    },
    longitude:{
        type:String,
        required:true
    },
    date:{
        type:Date,
        default: Date.now
    }
})


module.exports = mongoose.model('location',locationSchema);